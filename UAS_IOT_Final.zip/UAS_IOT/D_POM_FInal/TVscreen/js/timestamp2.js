let counter2 = 1
setInterval(() => {
    document.querySelector("#time2").innerText = counter2+ ' seconds ago';
    counter2++;
    if (counter2 > 5) counter2 = 1;
  }, 1000);