
setInterval(() => {
  function getData(){
 fetch('http://ip:3000/api/telemetry/getdevice3', { //or without port if allready set
       method: 'GET',
       headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization':'Bearer {process.env.TOKEN_SECR}',
        'Access-Control-Allow-Origin': '*'
       },
     })
     .then(function (response)
     {
       return response.text();
     })
     .then(function (text)
     {
       dataIn = text
     })
     .catch(function (error)
     {
       console.error(error)
     })
    }
    document.querySelector("#dev2").innerText = dataIn + ' Watt';
}, 5000);