let counter3 = 1
setInterval(() => {
    document.querySelector("#time3").innerText = counter3+ ' seconds ago';
    counter3++;
    if (counter3 > 5) counter3 = 1;
  }, 1000);