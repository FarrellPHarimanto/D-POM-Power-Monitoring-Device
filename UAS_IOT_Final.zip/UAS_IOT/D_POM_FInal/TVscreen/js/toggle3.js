let toggle3 = document.querySelector(".toggle3");
let text3 = document.querySelector("#text3");

function Animatedtoggleb(){
    toggle3.classList.toggle("active");

    if(toggle3.classList.contains("active")){
        text3.innerHTML = "ON";
        fetch('http://ip/api/control/led3', { //or with port 
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Headers': 'Origins, X-Requested-With, Content-Type, Accept',
        },
        body: '1'
        })
        .then(function (response)
        {
          return response.text();
        })
        .then(function (text)
        {
          if(text == 'Logged-in'){
        //    console.log("success control 1")
          }
          else{
            alert(text)
          }
        })
        .catch(function (error)
        {
          console.error(error)
        })
    }
    else{
        text3.innerHTML = "OFF";
        fetch('http://ip/api/control/led3', { //or with port 
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Headers': 'Origins, X-Requested-With, Content-Type, Accept',
        },
        body: '0'
        })
        .then(function (response)
        {
          return response.text();
        })
        .then(function (text)
        {
          if(text == 'Logged-in'){
        //    console.log("success control 1")
          }
          else{
            alert(text)
          }
        })
        .catch(function (error)
        {
          console.error(error)
        })
    }
}