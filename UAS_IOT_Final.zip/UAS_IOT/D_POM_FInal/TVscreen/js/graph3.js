const btn3 = document.querySelector(".button-3");
btn3.addEventListener("click", changegraph3);
      function changegraph3() {
        function rand() {
            return Math.random()*100;
        } 
        let dataIn3;
        var time = Date.now() + 25200000;
        var data = [{
            x: [time],
            y: [dataIn3],
            mode: 'lines',
            line: {color: '#80CAF6'}
        }]


        var layout = {
            uirevision:'true',
            height: 290,
            width: 1000,
            margin: {
                l: 60,
                r: 10,
                b: 23,
                t: 10,
                pad: 4
              }
          };
        Plotly.plot('chart', data, layout);

        var cnt = 0;

        function getData(){
          fetch('http://ip:3000/api/telemetry/getdevice3', { //or without port if allready set
                method: 'GET',
                headers: {
                  'Content-Type': 'application/json',
                  'Accept': 'application/json',
                  'Authorization':'Bearer {process.env.TOKEN_SECR}',
                  'Access-Control-Allow-Origin': '*'
                },
              })
              .then(function (response)
              {
                return response.text();
              })
              .then(function (text)
              {
                dataIn3 = text
              })
              .catch(function (error)
              {
                console.error(error)
              })
        }

        window.addEventListener('load', function () {
          // Your document is loaded.
          var fetchInterval = 1000; // 1 seconds.

          // Invoke the request every 1 seconds.
          setInterval(getData, fetchInterval);
        });

        //make interval a global variable
        interval = setInterval(function(){
            var time = new Date();
            var update = {
                x:  [[time]],
                y: [[dataIn]]
            }

            var olderTime = time.setMinutes(time.getMinutes() - 1);
            var futureTime = time.setMinutes(time.getMinutes() + 1);
            
            var minuteView = {
                xaxis: {
                type: 'date',
                range: [olderTime,futureTime]
                }
            };
            Plotly.relayout('chart', minuteView);
            Plotly.extendTraces('chart', update, [0]);



            if(cnt === 100){ 
            clearInterval(interval);}
            }, 1000);
        }