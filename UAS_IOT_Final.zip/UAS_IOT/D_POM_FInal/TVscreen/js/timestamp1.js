let counter1 = 1
setInterval(() => {
    document.querySelector("#time").innerText = counter1+ ' seconds ago';
    counter1++;
    if (counter1 > 5) counter1 = 1;
  }, 1000);