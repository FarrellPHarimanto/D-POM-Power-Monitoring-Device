const form = document.getElementById('login')

document.getElementById('login-button').onclick = function(){

  var email = document.getElementById('login-email').value
  var password = document.getElementById('login-password').value

  fetch('http://ip/api/user/login', { //or with port 
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Origins, X-Requested-With, Content-Type, Accept',
      },
      body: JSON.stringify({
        email,
        password
      })
      })
      .then(function (response)
      {
        return response.text();
      })
      .then(function (text)
      {
        if(text == 'Logged-in'){
          window.location.href = "http://ip:3000/dashboard"; //or without port if allready set
        }
        else{
          alert(text)
        }
      })
      .catch(function (error)
      {
        console.error(error)
      })
}
