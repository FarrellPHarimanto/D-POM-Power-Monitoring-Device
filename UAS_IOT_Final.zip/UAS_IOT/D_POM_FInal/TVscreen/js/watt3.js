
setInterval(() => {
   function getData(){
  fetch('http://ip:3000/api/telemetry/getdevice3', { //or without port if allready set
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Authorization':'Bearer {process.env.TOKEN_SECR}',
          'Access-Control-Allow-Origin': '*'
        },
      })
      .then(function (response)
      {
        return response.text();
      })
      .then(function (text)
      {
        dataIn3 = text
      })
      .catch(function (error)
      {
        console.error(error)
      })
     }
     document.querySelector("#dev3").innerText = dataIn3 + ' Watt';
}, 5000);