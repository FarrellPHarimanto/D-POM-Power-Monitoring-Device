const mongoose = require('mongoose');

const device3Schema = new mongoose.Schema({
    data: {
      type: String,
      required: true,
    },
    date: {
      type: Date,
      default: Date.now() + 25200000 //7 Hours in milli Scds
  }
});

module.exports = mongoose.model('device3', device3Schema);