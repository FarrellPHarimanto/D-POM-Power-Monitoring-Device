const mongoose = require('mongoose');

const device1Schema = new mongoose.Schema({
    data: {
      type: String,
      required: true,
    },
    date: {
      type: Date,
      default: Date.now() + 25200000 //7 Hours in milli Scds
  }
});

module.exports = mongoose.model('device1', device1Schema);

