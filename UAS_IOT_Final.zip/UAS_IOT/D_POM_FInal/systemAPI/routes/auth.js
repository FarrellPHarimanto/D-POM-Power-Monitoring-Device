const router = require('express').Router();
const User = require('../model/User');
// const GPIO = require('../model/GPIOcontrol');
const Data1 = require('../model/energyData/ED1');
const Data2 = require('../model/energyData/ED2');
const Data3 = require('../model/energyData/ED3');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const {registerValidation, loginValidation, postData, postControl} = require('../validation');

router.post('/register', async (req,res) => {
    //LETS VALIDADTE THE DATA BEFORE WE (property) Request.body: any
    const {error} = registerValidation(req.body);
    if(error) return res.status(400).send(error.details[0].message);
    
    //Checking if the email is already in the database
    const emailExist = await User.findOne({email: req.body.email});
    if(emailExist) return res.status(400).send('Email already exists');

    //Hash the passwords
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(req.body.password, salt);

    //Create a new user
    const user = new User({
        name: req.body.name,
        email: req.body.email,
        password: hashedPassword
    });
    try{
        const savedUser = await user.save();
        res.send({user: user._id});
    }catch(err){
        res.status(400).send(err);
    }
});

//LOGIN
router.post('/login', async (req,res) =>{
    const {error} = loginValidation(req.body);
    if(error) return res.status(400).send(error.details[0].message);

    //Checking if the email is in the database
    const user = await User.findOne({email: req.body.email});
    if(!user) return res.status(400).send('Invalid Email');
    //Password is correct
    const validPass = await bcrypt.compare(req.body.password, user.password);
    if(!validPass) return res.status(400).send('Invalid Password');

    //Create and assign a token
    const token = jwt.sign({_id: user._id}, process.env.TOKEN_SECRET)
    res.header('auth-token', token).send(token);
}); 

//telemetry

router.post('/device1', async (req,res) =>{
    //LETS VALIDADTE THE DATA BEFORE WE (property) Request.body: any
    const {error} = postData(req.body);
    if(error) return res.status(400).send(error.details[0].message);

    //Create a new data telemetry
    const data = new Data1({
        data: req.body.data
    });
    try{
        const savedData = await data.save();
        res.send("success");
    }catch(err){
        res.status(400).send(err);
    }
});

router.post('/device2', async (req,res) =>{
    //LETS VALIDADTE THE DATA BEFORE WE (property) Request.body: any
    const {error} = postData(req.body);
    if(error) return res.status(400).send(error.details[0].message);

    //Create a new data telemetry
    const data = new Data2({
        data: req.body.data
    });
    try{
        const savedData = await data.save();
        res.send({user: data._id});
    }catch(err){
        res.status(400).send(err);
    }
}); 
router.post('/device3', async (req,res) =>{
    //LETS VALIDADTE THE DATA BEFORE WE (property) Request.body: any
    const {error} = postData(req.body);
    if(error) return res.status(400).send(error.details[0].message);

    //Create a new data telemetry
    const data = new Data3({
        data: req.body.data
    });
    try{
        const savedData = await data.save();
        res.send({user: data._id});
    }catch(err){
        res.status(400).send(err);
    }
}); 

//controlling gpio
router.post('/control1', async (req,res) =>{
    //LETS VALIDADTE THE DATA BEFORE WE (property) Request.body: any
    const {error} = postControl(req.body);
    if(error) return res.status(400).send(error.details[0].message);

    //Checking if the device want to control is in the database
    const deviceExist = await GPIO.findOne({email: req.body.email});
    if(!deviceExist) return res.status(400).send('no device to control')
    //Create a new data telemetry
    const Device = new Data({
        deviceNo: req.body.deviceNo,
        data: req.body.data
    })
    //Create and assign a token
    const token = jwt.sign({_id: GPIO._id}, process.env.TOKEN_SECRET)
    res.header('auth-token', token).send('Success');
});

module.exports = router;