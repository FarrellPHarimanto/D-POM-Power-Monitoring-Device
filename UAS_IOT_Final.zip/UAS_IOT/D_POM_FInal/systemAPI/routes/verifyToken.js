const jwt = require('jsonwebtoken')

module.exports = function (err, req,res,next){
    const token = req.header('Authorization');
    if(!token) return res.status(401).send('Access Denied');

    try{
        const verified = jwt.verify(token, process.env.TOKEN_SECRET);
        req.user = verified;
        res.header('Access-Control-Allow-Origin', req.headers.origin);
        res.setHeader("Access-Control-Allow-Credentials", "true");
        res.setHeader("Access-Control-Allow-Methods", "GET,HEAD,OPTIONS,POST,PUT");
        res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");
        
        return next();
    }catch {err} {
        return res.status(400).send('Invalid Token')
    }
}