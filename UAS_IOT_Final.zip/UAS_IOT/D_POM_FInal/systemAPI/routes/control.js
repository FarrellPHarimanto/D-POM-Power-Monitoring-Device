const router = require('express').Router();
const verify = require('./verifyToken');
const GPIO1 = require('../model/GPIOcontrol/LED1');
const GPIO2 = require('../model/GPIOcontrol/LED2');
const GPIO3 = require('../model/GPIOcontrol/LED3');
const {postControl} = require('../validation');


//controlling gpio POST
router.post('/led1', verify, async (req,res) =>{
    //LETS VALIDADTE THE DATA BEFORE WE (property) Request.body: any
    const {error} = postControl(req.body);
    if(error) return res.sendStatus(400).send(error.details[0].message);
    else{
        //Create a new data telemetry
        // const Device = GPIO1.updateOne({})
        const Device = new GPIO1({
            led: req.body.led
        })
        try{
            // const savedData = await Device;
            const savedData = await Device.save();
            return res.send("success");
        }catch(err){
            return res.sendStatus(400).send(err);
        }
    }
});

router.post('/led2', verify, async (req,res) =>{
    //LETS VALIDADTE THE DATA BEFORE WE (property) Request.body: any
    const {error} = postControl(req.body);
    if(error) return res.sendStatus(400).send(error.details[0].message);
    else{
        //Create a new data telemetry
       // const Device = GPIO1.updateOne({})
       const Device = new GPIO2({
            led: req.body.led
        })
        try{
            // const savedData = await Device;
            const savedData = await Device.save();
            return res.send("success");
        }catch(err){
            return res.sendStatus(400).send(err);
        }
    }
});

router.post('/led3', verify, async (req,res) =>{
    //LETS VALIDADTE THE DATA BEFORE WE (property) Request.body: any
    const {error} = postControl(req.body);
    if(error) return res.sendStatus(400).send(error.details[0].message);
    else{
        //Create a new data telemetry
       // const Device = GPIO1.updateOne({})
       const Device = new GPIO3({
            led: req.body.led
        })
        try{
            // const savedData = await Device;
            const savedData = await Device.save();
            return res.send("success");
        }catch(err){
            return res.sendStatus(400).send(err);
        }
    }
});

//gpio controll GET
router.get('/getled1', verify, async (req,res) =>{
    GPIO1.find().then(function(records){
        // res.send(JSON.stringify(records[0].led))
        res.send(records[records.length-1].led)
      });
});
router.get('/getled2', verify, async (req,res) =>{
    GPIO2.find().then(function(records){
        // res.send(JSON.stringify(records[0].led))
        res.send(records[records.length-1].led)
      });
});
router.get('/getled3', verify, async (req,res) =>{
    GPIO3.find().then(function(records){
        // res.send(JSON.stringify(records[0].led))
        res.send(records[records.length-1].led)
      });
});
module.exports = router;