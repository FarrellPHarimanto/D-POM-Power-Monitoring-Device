const router = require('express').Router();
const verify = require('./verifyToken');
const Data1 = require('../model/energyData/ED1');
const Data2 = require('../model/energyData/ED2');
const Data3 = require('../model/energyData/ED3');
const {postData} = require('../validation');
//telemetry

router.post('/device1', verify, async (req,res) =>{
    //LETS VALIDADTE THE DATA BEFORE WE (property) Request.body: any
    const {error} = postData(req.body);
    if(error) return res.status(400).send(error.details[0].message);

    //Create a new data telemetry
    const data = new Data1({
        data: req.body.data
    });
    try{
        const savedData = await data.save();
        res.send("success");
    }catch(err){
        res.status(400).send(err);
    }
});

router.post('/device2', verify, async (req,res) =>{
    //LETS VALIDADTE THE DATA BEFORE WE (property) Request.body: any
    const {error} = postData(req.body);
    if(error) return res.status(400).send(error.details[0].message);

    //Create a new data telemetry
    const data = new Data2({
        data: req.body.data
    });
    try{
        const savedData = await data.save();
        res.send("success");
    }catch(err){
        res.status(400).send(err);
    }
}); 
router.post('/device3', verify, async (req,res) =>{
    //LETS VALIDADTE THE DATA BEFORE WE (property) Request.body: any
    const {error} = postData(req.body);
    if(error) return res.status(400).send(error.details[0].message);

    //Create a new data telemetry
    const data = new Data3({
        data: req.body.data
    });
    try{
        const savedData = await data.save();
        res.send("success");
    }catch(err){
        res.status(400).send(err);
    }
}); 

//get latest data req GET
router.get('/getdevice1', verify, async (req,res) =>{
    Data1.find().then(function(records){
        // res.send(JSON.stringify(records[0].led))

        res.send(records[records.length-1].data)
      });
});
router.get('/getdevice2', verify, async (req,res) =>{
    Data2.find().then(function(records){
        // res.send(JSON.stringify(records[0].led))

        res.send(records[records.length-1].data)
      });
});
router.get('/getdevice3', verify, async (req,res) =>{
    Data3.find().then(function(records){
        // res.send(JSON.stringify(records[0].led))

        res.send(records[records.length-1].data)
      });
});

module.exports = router;