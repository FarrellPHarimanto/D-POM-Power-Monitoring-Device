const express = require('express');
const sessions = require('express-session');
const cors = require('cors');
const app = express();
const dotenv = require('dotenv');
const mongoose = require('mongoose');
var path = require('path');

//Import Routes
const authRoute = require('./routes/auth');
const postData = require('./routes/data');
const postControl = require('./routes/control');
const postRoute = require('./routes/posts');

dotenv.config();

//Connect to DB
mongoose.connect(process.env.DB_CONNECT, { useNewUrlParser: true }, () => 
    console.log('connected to DB!')
);

mongoose.connection.on('error', err => {
    console.log(err);
})


var auth = function(req,res,next){
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    res.header('Expires', '-1');
    res.header('Pragma', 'no-cache');
    if (!req.session.userId){
        return res.redirect("/login");
    } else{
        return next();
    }
};

//Static Files
app.use(express.static('../TVscreen'));

const oneDay = 1000 * 60 * 60 * 24;
app.use(sessions({
    secret: "thisismysecrctekeyfhrgfgrfrty84fwir767",
    saveUninitialized:true,
    cookie: { maxAge: oneDay },
    resave: false 
}));

//geting input
app.get('/login', (req,res) => {
    res.sendFile(path.resolve('../TVscreen/html/login.html'))
})

app.get('/dashboard',auth, (req,res) => {
    res.sendFile(path.resolve('../TVscreen/html/dashboard.html'))
})

app.get('/logout', (req,res) => {
    req.session.destroy();
    res.redirect('/login');
});

//Middleware
app.use(express.json());
//Route Middlewares
app.use(cors());
app.options('*', cors());
app.use('/api/u', authRoute);
app.use('/api/user', postRoute);
app.use('/api/telemetry', postData);
app.use('/api/control', postControl);

app.listen(3000, () => console.log('Server up and running'));